from tester import *

from PIL import Image

success()
